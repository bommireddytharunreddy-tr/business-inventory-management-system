from fastapi import FastAPI

from app.databases.connection import engine, Base
from app.models.product import Product
from app.routers.products import router as product_router
from app.models.category import Category
from app.routers.categories import router as category_router
from app.models.supplier import Supplier
from app.routers.suppliers import router as supplier_router
from app.models.customer import Customer
from app.routers.customers import router as customer_router
from app.models.purchase import Purchase
from app.models.purchase_item import PurchaseItem
from app.routers.purchases import router as purchase_router
from app.models.sale import Sale
from app.models.sale_item import SaleItem
from app.routers.sales import router as sale_router
from app.models.user import User
from app.routers.auth import router as auth_router


app = FastAPI(
    title="Hardware Store API",
    version="1.0.0"
)

# Create all database tables
Base.metadata.create_all(bind=engine)
app.include_router(product_router)
app.include_router(category_router)
app.include_router(supplier_router)
app.include_router(customer_router)
app.include_router(purchase_router)
app.include_router(sale_router)
app.include_router(auth_router)

@app.get("/")
def home():
    return {"message": "Welcome to Hardware Store API"}

